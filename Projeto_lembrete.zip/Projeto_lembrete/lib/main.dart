import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lembretes',
      home: MyHomePage(),
    );
  }
} //Widget principal do aplicativo

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
} //Página principal do aplicativo

class _MyHomePageState extends State<MyHomePage> {
  final TextEditingController _nameController =
      TextEditingController(); //Variável responsável pela caixa do espaço do nome do lembrete
  DateTime?
      _selectedDate; //Variável reposnsável por averiguar a data informada pelo usuário
  Map<String, List<Map<String, dynamic>>> _reminders =
      {}; //mapa usado para armazenar os lembretes

  void _deleteReminder(String date, int index) {
    setState(() {
      _reminders[date]?.removeAt(index);

      if (_reminders[date]?.isEmpty ?? true) {
        _reminders.remove(date);
      }
    });
    //função usada para que seja possível excluir um lembrete específico
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() {
        _selectedDate = picked;
      });
    }
    //Função usada para que o usuário selecione uma data para o lembrete
  }

  bool _isDateInPast(DateTime date) {
    final today = DateTime.now();
    return date.isBefore(DateTime(today.year, today.month, today.day));
    //Função que verifica se a data escolhida está no passado
  }

  @override
  Widget build(BuildContext context) {
    //Este método constrói a interface do usuário, tendo em sua construção as caixas de texto e a lista de lembretes.
    return Scaffold(
      appBar: AppBar(
        title: Text('Novos Lembretes'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(children: [
          TextField(
            //TextField usado para o nome do lembrete
            controller: _nameController,
            decoration: const InputDecoration(
              hintText: 'Ex: Estudar biologia', //Placeholder
              labelText: 'Nome do Lembrete',
              border: OutlineInputBorder(
                borderSide: BorderSide(
                  color: Colors.blue,
                  width: 2.0,
                ),
              ),
            ),
          ),
          SizedBox(height: 16.0),
          TextField(
            //TextField usado para data do lembrete
            decoration: const InputDecoration(
              labelText: 'Data do Lembrete',
              hintText: 'Ex: 10/06/2024', //Placeholder
              border: OutlineInputBorder(
                borderSide: BorderSide(
                  color: Colors.blue,
                  width: 2.0,
                ),
              ),
            ),
            onChanged: (value) {
              if (value.isNotEmpty) {
                try {
                  final date = DateFormat('dd/MM/yyyy').parse(value);
                  setState(() {
                    _selectedDate = date;
                  });
                  // ignore: empty_catches
                } catch (e) {}
              }
            },
          ),
          SizedBox(height: 16.0),
          Align(
            alignment: Alignment.centerRight,
            child: ElevatedButton(
              onPressed: _selectedDate == null ||
                      _nameController.text
                          .isEmpty //Verifica se a parte do nome e da data estão preenchidos para que haja a criação do lembrete
                  ? null
                  : () {
                      if (_selectedDate != null &&
                          _isDateInPast(_selectedDate!)) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text(
                              'Data inválida, por favor insira uma data válida.',
                            ),
                          ),
                        );
                      } else {
                        String name = _nameController.text;
                        final dateKey =
                            DateFormat('dd/MM/yyyy').format(_selectedDate!);
                        _reminders[dateKey] ??= [];
                        setState(() {
                          _reminders[dateKey]!.add({'name': name});
                        });
                        _nameController.clear();
                        _selectedDate = null;
                      }
                    },
              style: ButtonStyle(
                //Estilização do botão "Criar"
                backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                padding: MaterialStateProperty.all<EdgeInsetsGeometry>(
                    EdgeInsets.all(10)),
                textStyle: MaterialStateProperty.all<TextStyle>(
                    TextStyle(color: Colors.black)),
                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                    RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                  side: BorderSide(color: Colors.blue),
                )),
              ),
              child: Text('Criar'),
            ),
          ),
          if (_reminders
              .isNotEmpty) //Checa se a lista está com algum lembrete para aparecer: "Lista de lembretes"
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Lista de lembretes',
                style: TextStyle(fontSize: 18.0),
              ),
            ),
          Expanded(
            child: _reminders.isEmpty
                ? const Center(
                    child: Text(
                      'Nenhum lembrete pendente ;)', // Mensagem que aparece caso _reminders esteja sem lembretes
                      style: TextStyle(fontSize: 16.0),
                    ),
                  )
                : ListView.builder(
                    //construtor que faz com que os lembretes tomem um formato de uma lista
                    itemCount: _reminders.length,
                    itemBuilder: (context, index) {
                      final date = _reminders.keys.toList()[index];
                      final reminders = _reminders[date]!;
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            date,
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                          ListView.builder(
                            shrinkWrap: true,
                            physics: ClampingScrollPhysics(),
                            itemCount: reminders.length,
                            itemBuilder: (context, idx) {
                              final reminder = reminders[idx];
                              return ListTile(
                                title: Text(reminder['name']),
                                trailing: IconButton(
                                  //Ícone que permite a exclusão de algum dos lembretes
                                  icon: Icon(Icons.delete),
                                  onPressed: () => _deleteReminder(date, idx),
                                ),
                              );
                            },
                          ),
                        ],
                      );
                    },
                  ),
          ),
        ]),
      ),
    );
  }
}
